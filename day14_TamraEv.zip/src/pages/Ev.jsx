import React from 'react';

const Ev = () => {
    return (
        <div style={{ width: '1200px',margin: "auto"}}>
            <img src="./images/bg_info_1.png" alt="" />
        </div>
    );
};

export default Ev;