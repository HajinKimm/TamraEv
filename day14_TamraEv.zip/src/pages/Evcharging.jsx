import React from 'react';

const Evcharging = () => {
    return (
        <div>
            <h2>전기차 충전소</h2>
        </div>
    );
};

export default Evcharging;