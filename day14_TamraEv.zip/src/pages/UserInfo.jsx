import React from 'react';

const UserInfo = () => {
    return (
        <div>
            <h2>개인정보처리방침</h2>
        </div>
    );
};

export default UserInfo;