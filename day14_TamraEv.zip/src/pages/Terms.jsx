import React from 'react';

const Terms = () => {
    return (
        <div>
            <h2>이용약관</h2>
        </div>
    );
};

export default Terms;